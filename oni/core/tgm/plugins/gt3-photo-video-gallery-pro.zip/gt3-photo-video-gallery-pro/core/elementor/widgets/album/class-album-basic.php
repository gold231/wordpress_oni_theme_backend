<?php
namespace GT3\PhotoVideoGalleryPro\Elementor\Widgets\Album;
defined('ABSPATH') OR exit;

use GT3_Post_Type_Gallery;
use Elementor\Controls_Manager;
use Elementor\GT3_Core_Elementor_Control_Gallery;
use GT3\PhotoVideoGalleryPro\Elementor\Widgets\Basic;

abstract class Album_Basic extends Basic {
	const POST_TYPE = GT3_Post_Type_Gallery::post_type;
	const TAXONOMY = GT3_Post_Type_Gallery::taxonomy;

}
